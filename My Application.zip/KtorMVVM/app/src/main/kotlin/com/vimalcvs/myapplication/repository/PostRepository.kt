package com.vimalcvs.myapplication.repository

import com.vimalcvs.myapplication.model.ModelList
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.get
import javax.inject.Inject
import javax.inject.Singleton


@Singleton
class PostRepository @Inject constructor(private val client: HttpClient) {

    suspend fun getPosts(): List<ModelList> {
        return client.get("https://jsonplaceholder.typicode.com/posts")
            .body()
    }
}