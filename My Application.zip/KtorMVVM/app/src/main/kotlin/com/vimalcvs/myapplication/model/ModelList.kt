package com.vimalcvs.myapplication.model

import kotlinx.serialization.Serializable

@Serializable
data class ModelList(
    val body: String,
    val id: Int,
    val title: String,
    val userId: Int
)